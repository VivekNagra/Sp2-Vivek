public class Main
{
    public static void main(String[] args)
    {

        FleetOfCars fleet = new FleetOfCars();


        fleet.addCar(new GasolinCar("PD 12 567", "Hyundai", "i20", 5, 22));
        fleet.addCar(new GasolinCar("DS 98 897", "Ford", "Fiesta", 5, 15));
        fleet.addCar(new GasolinCar("GF 34 546", "Skoda", "Octavia", 5, 45));

        fleet.addCar(new DieselCar("LK 45 875", "Audi", "A6", 5, 39, true));
        fleet.addCar(new DieselCar("LS 89 428", "Nissan", "Note", 5, 45, false));
        fleet.addCar(new DieselCar("CM 23 972", "Mercedes", "E220", 7, 23, true));

        fleet.addCar(new ElectricCar("AP 34 564", "Mercedes", "EQC500", 5, 80, 502));
        fleet.addCar(new ElectricCar("AT 56 234", "Tesla", "Model S", 5, 110, 510));
        fleet.addCar(new ElectricCar("XC 78 209", "Rolls Royce", "Spectre", 3, 80, 380));

        System.out.println(fleet);
        System.out.println("The total car tax = " + fleet.getTotalRegistrationFeeForFleet());


    }
}
